1)run segment.m file 
2)click on upload button to upload an image of an eye
3)click on show segmented image model1 button  to  view the segmented image of model1 
4)click on show segmented image model2 button  to  view the segmented image of model2 which is extracted from model1 .